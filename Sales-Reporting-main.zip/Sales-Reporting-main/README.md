# Sales_Reporting

Youtube Tutorial: https://youtu.be/VH2JgqlN2so

Conduct a Report and Analysis on 200,000 sales data points to answer revenue-related questions for the business
